#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include "strutil.h"
#include "pila.h"

/* *****************************************************************
 *                      FUNCIONES AUXILIARES
 * *****************************************************************/
 
int operacion_fallida(char* linea,pila_t* pila){
	pila_destruir(pila);
	free(linea);
	fprintf(stderr, "Error, la operacion ingresada no es valida\n");
	return -1;
}

bool es_suma(char* cad){
	if(!strcmp(cad,"+") || !strcmp(cad,"+\n") || !strcmp(cad,"+\0"))
		return true;
	return false;
}

bool es_resta(char* cad){
	if(!strcmp(cad,"-") || !strcmp(cad,"-\n") || !strcmp(cad,"-\0"))
		return true;
	return false;
}

bool es_producto(char* cad){
	if(!strcmp(cad,"*") || !strcmp(cad,"*\n") || !strcmp(cad,"*\0"))
		return true;
	return false;
}

bool es_division(char* cad){
	if(!strcmp(cad,"/") || !strcmp(cad,"/\n") || !strcmp(cad,"/\0"))
		return true;
	return false;
}

bool es_operacion(char* cad){
	if(es_suma(cad) || es_resta(cad) || es_division(cad) || es_producto(cad))
		return true;
	return false;
}

/* *****************************************************************
 *                      FUNCION PRICIPAL
 * *****************************************************************/

int main(void){
	char* linea = NULL;
	char* sub_cad;
	char* cad_fin;
	char** array_cad;
	double numero,resultado;
	size_t capacidad = 0,pos_aux = 0, pos_array = 0;
	ssize_t len = getline(&linea, &capacidad,stdin);
	if (len==-1){
		fprintf(stderr, "Error, no se puede leer la linea\n");
		return -1;
	}
	pila_t* pila_num = pila_crear();
	double array_aux[len*2]; 
	while(len!=-1){
		array_cad = split(linea, ' ');
		while(array_cad[pos_array]){
			sub_cad = array_cad[pos_array];
			if(es_operacion(sub_cad)){
				double* num1 = (double*)pila_desapilar(pila_num);
				double* num2 = (double*)pila_desapilar(pila_num);
				if(!num1 || !num2 ){
					free_strv(array_cad);
					return operacion_fallida(linea,pila_num);
				}
				if(es_suma(sub_cad)){
					resultado = *num2 + *num1;
					array_aux[pos_aux] = resultado;
					pila_apilar(pila_num,array_aux+pos_aux);
					pos_array++;
					pos_aux++;
					continue;
				}
				if(es_resta(sub_cad)){
					resultado = *num2 - *num1;
					array_aux[pos_aux] = resultado;
					pila_apilar(pila_num,array_aux+pos_aux);
					pos_array++;
					pos_aux++;
					continue;
				}
				if(es_division(sub_cad)){
					resultado = *num2 / *num1;
					array_aux[pos_aux] = resultado;
					pila_apilar(pila_num,array_aux+pos_aux);
					pos_aux++;
					pos_array++;
					continue;
				}
				if(es_producto(sub_cad)){
					resultado = *num2 * *num1;
					array_aux[pos_aux] = resultado;
					pila_apilar(pila_num,array_aux+pos_aux);
					pos_array++;
					pos_aux++;
					continue;
				}
			}
			if(!strcmp(sub_cad,"") || !strcmp(sub_cad,"\n") ){
				pos_array++;
				continue;
			}
			numero = strtod(sub_cad, &cad_fin);
			if(!strcmp(cad_fin,"") || !strcmp(cad_fin,"\n")){
				array_aux[pos_aux] = numero;
				pila_apilar(pila_num,array_aux+pos_aux);
				pos_array++;
				pos_aux++;
				continue;
			}
			free_strv(array_cad);
			return operacion_fallida(linea,pila_num);
		}
		if(pila_esta_vacia(pila_num)){
			free_strv(array_cad);
			return operacion_fallida(linea,pila_num);
		}
		double* resultado_final = (double*)pila_desapilar(pila_num);
		if(!pila_esta_vacia(pila_num)){
			free_strv(array_cad);
			return operacion_fallida(linea,pila_num);
			}	
		printf("Resultado = %.2f\n",*resultado_final);
		pos_array = 0;
		pos_aux = 0;
		free_strv(array_cad);
		len = getline(&linea, &capacidad,stdin);
	}
	pila_destruir(pila_num);
	free(linea);
	return 0;
}
